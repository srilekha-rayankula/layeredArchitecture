package com.cg.tms.dao;



import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

import junit.framework.Assert;

class JunitTest {
	private static Map<String,TicketBean> ticketLog1=new HashMap<String,TicketBean >();
	TicketCategory tc=new TicketCategory("t2", "mailbox");
	TicketBean tb=new TicketBean("1002", tc, "problem", "high", "new");
	@SuppressWarnings("deprecation")
	@Test
	public  void raiseNewTicket() {
		
		
		ticketLog1.put(tb.getTicketNo(), tb);
		String s=tb.getTicketNo();
		int expected=1002;
		int i=Integer.parseInt(s);
		Assert.assertEquals(expected, i);
	}

}
