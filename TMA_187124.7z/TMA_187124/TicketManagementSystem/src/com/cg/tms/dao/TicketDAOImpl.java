package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImpl implements TicketDAO {

	private static Map<String, TicketBean> Log = new HashMap<String, TicketBean>();

	public static Map<String, String> getTicketCategoryEntries() {        //Given Details
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
	}

	@Override
	public int raiseNewTicket(TicketBean ticketBean) {        //Raising ticket
		

		Log.put(ticketBean.getTicketNo(), ticketBean);
		String str = ticketBean.getTicketNo();
		int j = Integer.parseInt(str);
		return j;
	}
	
	private static Map<String, String> ticketCategory = new HashMap<String, String>();
	
	@Override
	public List<TicketCategory> listTicketCategory() {               //Getting ticket Categories
		
		List<TicketCategory> list = new ArrayList<TicketCategory>();
		
		Map<String, String> map = TicketDAOImpl.getTicketCategoryEntries();
		@SuppressWarnings("unused")
		int j = 1;
		for (Map.Entry<String, String> entry : map.entrySet()) {
			
			TicketCategory tcat = new TicketCategory(entry.getKey(), entry.getValue());
			
			list.add(tcat);

		}

		return list;
	}

}
