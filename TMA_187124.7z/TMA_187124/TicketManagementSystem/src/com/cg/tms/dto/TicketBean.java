package com.cg.tms.dto;
public class TicketBean {
	private String ticketNo;
	private TicketCategory ticketcategory;
	private String ticketDescription;
	private String ticketPriority;
	private String ticketStatus;
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public TicketCategory getTicketcategory() {
		return ticketcategory;
	}
	public void setTicketcategory(TicketCategory ticketcategory) {
		this.ticketcategory = ticketcategory;
	}
	public String getTicketDescription() {
		return ticketDescription;
	}
	public void setTicketDescription(String ticketDescription) {
		this.ticketDescription = ticketDescription;
	}
	public String getTicketPriority() {
		return ticketPriority;
	}
	public void setTicketPriority(String ticketPriority) {
		this.ticketPriority = ticketPriority;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	public TicketBean(String ticketNo, TicketCategory ticketcategory, String ticketDescription, String ticketPriority,
			String ticketStatus) {
		super();
		this.ticketNo = ticketNo;
		this.ticketcategory = ticketcategory;
		this.ticketDescription = ticketDescription;
		this.ticketPriority = ticketPriority;
		this.ticketStatus = ticketStatus;
	}
	
}
