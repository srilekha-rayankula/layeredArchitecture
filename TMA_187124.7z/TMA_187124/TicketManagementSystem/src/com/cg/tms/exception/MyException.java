package com.cg.tms.exception;

@SuppressWarnings("serial")
public class MyException extends Exception{
	String s1;
	 public MyException(String s) {
		 s1=s;
	 }
	 public String toString() {
		 return(s1);
	 }
}
