package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;


import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.MyException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	static TicketService tser = new TicketServiceImpl();

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		while (true) {
			int ch;
			@SuppressWarnings("unused")
			boolean x = true;
			System.out.println("Welcome to ITIMD Help Desk\n\n");
			System.out.println("  1.Raise a ticket\n  2.Exit from System\n ");
			try {
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				List<TicketCategory> l1 = tser.listTicketCategory();
		
				System.out.println("Select category from following list: \n ");
				
				for (int i = 0; i < l1.size(); i++) {
					System.out.println((i + 1) + ". " + l1.get(i).getCategoryName());
				}
				
				System.out.println("enter your option :");
				int choice = sc.nextInt();

				TicketCategory tcat = new TicketCategory(l1.get(choice).getTicketCategoryId(), l1.get(choice).getCategoryName());
				
				System.out.println("enter description related to issue :");
				String desc = sc.next();
				
				desc += sc.nextLine();
				
				System.out.println("enter Priority(1.low 2.medium 3.high :");
				
				int prty = sc.nextInt();          //Getting the priority 
				
				String priority = "";
				if (prty == 1) {
					priority = "low";
				} else if (prty == 2) {
					priority = "medium";
				}
				if (prty == 3) {
					priority = "high";
				}
				int ticketNumber = (int)((Math.random() * ((9999 - 1000) + 1)) + 1000); //generate ticket number
				
				String ticketNo1 = Integer.toString(ticketNumber);
				
				String ticketStatus = "New";         //should be always new
				
				TicketBean tb = new TicketBean(ticketNo1, tcat, desc, priority, ticketStatus);
				int i = tser.raiseNewTicket(tb);
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
				LocalDateTime now = LocalDateTime.now();
				System.out.println("Ticket Number " + i + " logged succesfully at " + dtf.format(now));
				break;
			case 2:
				System.out.println("Thank You!!....");
				System.exit(0);
			default:
				throw new MyException("Enter valid option");
			}
			}catch (MyException E) {
				System.out.println(E);
				ch = sc.nextInt();
		}
	}
}
}
