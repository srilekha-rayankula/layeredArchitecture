package com.parllel.Beans;

public class BankBean {
	private long accNo;
	private long mobNo;
	private String name;
	private long balance;
	private String tran;
	public String getTran() {
		return tran;
	}

	public void setTran(String tran) {
		this.tran = tran;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public long getMobNo() {
		return mobNo;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public BankBean(long accNo, long mobNo, String name, long balance) {
		super();
		this.accNo = accNo;
		this.mobNo = mobNo;
		this.name = name;
		this.balance = balance;
	}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return accNo+" "+name+" "+mobNo+" "+balance;
}
}
