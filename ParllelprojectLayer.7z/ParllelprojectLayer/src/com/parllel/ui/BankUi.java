package com.parllel.ui;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.parllel.Beans.BankBean;
import com.parllel.Service.BankService;
public class BankUi {
	static BankService bs = new BankService();
	static Scanner sc = new Scanner(System.in);
public static void main(String[] args) {
	int ch;
	char choice;
	
	Scanner sc = new Scanner(System.in);
	do {
		System.out.println("\n *********************\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n*********************");
		System.out.print("Enter your choice : ");
		ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Enter Your Name");
			String name = nameCheck(sc.next());
			System.out.println("Enter Your PhoneNumber");
			long mobNo = mobcheck(sc.nextLong());	
			long accNo = mobNo-1000;
			System.out.println("Enter your Balance");
			int balance = balCheck(sc.nextInt());
			BankBean bean=new BankBean(accNo, mobNo, name, balance);
			boolean res = bs.AccountCreateser(bean);
			if(res) {
				System.out.println("Your Account created with AccountNumber : "+accNo);
			}
			else
				System.out.println("Enter Valid Details");
			break;
		case 2:
			System.out.println("Enter Your Account Number");
		    accNo =  sc.nextLong();
		    long bal = bs.ShowBalanceser(accNo);
		    System.out.println("Your balance is  : "+bal);
			break;
		case 3:
			System.out.println("Enter Your Account Number");
			accNo = sc.nextLong();
			System.out.println("Enter Ammount to be deposited");
			int depAmt = balCheck(sc.nextInt());
			long updatebal = bs.DepositAmt(accNo,depAmt);
			System.out.println("Balance is : "+updatebal);
			break;
		case 4:
			System.out.println("Enter Your Account Number");
			accNo = sc.nextLong();
			System.out.println("Enter Ammount to be Withdraw");
			int withdAmt =  balCheck(sc.nextInt());
			long updatebalance = bs.WithdrawAmt(accNo,withdAmt);
			System.out.println("Remaining Balance is"+updatebalance);
			break;
		case 5:
			System.out.println("Enter Source Account Number");
			long sourceAccNo = sc.nextLong();
			System.out.println("Enter Your Destination Account Number");
			long destAccNo = sc.nextLong();
			System.out.println("Enter Transfer Ammount");
			int transferAmt = balCheck(sc.nextInt());
			long update1 = bs.TransferAmt(sourceAccNo,destAccNo,transferAmt);
			System.out.println("Your Balance after transfer is : "+update1);
			break;
		case 6:
			
				System.out.println("Enter your Account number :");
			    accNo = sc.nextLong();
				String st=bs.getTransaction(accNo);

				System.out.println("----------Account Statement----------\n");

				System.out.println(st);
			
			break;
		case 7:
			System.exit(0);
		}
		System.out.print("Do you want to continue (y/n)...? : ");
		choice = sc.next().charAt(0);
		if(choice == 'y' || choice=='Y')
			continue;
		else {
			System.out.println("Thank You !");
			System.exit(0);
			}
	}while(ch!=7);
	  
}
   private static int balCheck(int amount) {
	   while(true) {
			if(amount<=0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			}
			else {
				return amount;
			}
		}
   }
  public static String nameCheck(String name) {
	   while(true) {
			if(Pattern.matches("([A-Z])*([a-z])*", name)){
				return name;
			}
			else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
  }
  public static long mobcheck(long mob) {
	 while(true) {
	  if(String.valueOf(mob).length() < 10) {
		System.out.println("Enter valid mobile number.");
		mob = sc.nextLong();
	  }
	  else {
		return mob;
	  }
	}
  }
   
}



