package com.parllel.Service;

import com.parllel.Beans.BankBean;
import com.parllel.Dao.BankDao;

public class BankService {
	
	BankDao bd = new BankDao();
	BankBean bankBean;
	public boolean AccountCreateser(BankBean bean) {
		boolean res = bd.AccountCreateser(bean);
		return res;
	}
	public long ShowBalanceser(long accNo) {
		
		return bd.ShowBalanceser(accNo);
	}

	public long DepositAmt(long accNo,int depAmt) {
		//bankBean.setWithdAmt(depAmt);
		return bd.DepositAmt(accNo,depAmt);
	}
    public long WithdrawAmt(long accNo, int withdAmt) {
		//bankBean.setWithdAmt(withdAmt);
		return bd.WithdrawAmt(accNo,withdAmt);
	}
	public long TransferAmt(long SourceAccNo,long destAccNo,int transferAmt) {
		long bal = bd.TransferAmt(SourceAccNo,destAccNo,transferAmt);
		return bal;
		
	}
	public String getTransaction(long accNo) {
		  
		return bd.getTransaction(accNo);
	}
	

}
