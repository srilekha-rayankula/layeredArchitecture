package com.parllel.Dao;

import java.util.HashMap;
import java.util.Random;

import com.parllel.Beans.BankBean;

public class BankDao {
	HashMap<Long, BankBean> hm = new HashMap<Long, BankBean>();
      Random rand = new Random();
      BankBean bankBean;
	public boolean AccountCreateser(BankBean bankBean) {
		hm.put(bankBean.getAccNo(), bankBean);
		//System.out.println(hm);
		//System.out.println(hm.size()+"****************");
		String tran = "******Your Account is Created******** with Balance"+bankBean.getBalance()+"\n";
		bankBean.setTran(tran);
		return true;
	}

	public long ShowBalanceser(long accNo) {
		long bal = 0;
		if (hm.containsKey(accNo)) {
		   BankBean	bankBean = (BankBean) hm.get(accNo);
			bal =bankBean.getBalance();
			
		}
		return bal;
	}

	public long DepositAmt(long accNo, int depAmt) {
		long updatebal = 0;
		if (hm.containsKey(accNo)) {
			BankBean	bankBean = (BankBean) hm.get(accNo);
			updatebal = bankBean.getBalance() + depAmt;
			bankBean.setBalance((int) updatebal);
			long uniqueID = rand.nextInt(100000); 
			String tran=bankBean.getTran()+"Transaction ID : "+uniqueID+" Account Credited by : "+updatebal+" \n";
			bankBean.setTran(tran);
		}
		return updatebal;
	}

	public long WithdrawAmt(long accNo, int withdAmt) {
		long updatebalance = 0;
		if (hm.containsKey(accNo)) {
			BankBean bankBean = (BankBean) hm.get(accNo);
			updatebalance = bankBean.getBalance() - withdAmt;
			bankBean.setBalance((int) updatebalance);
			long uniqueID = rand.nextInt(100000); 
			String tran=bankBean.getTran()+"Transaction ID : "+uniqueID+" Account Debited by : "+updatebalance+" \n";
			
			bankBean.setTran(tran);
		}
		
		return updatebalance;
	}

	public long TransferAmt(long SourceAccNo, long destAccNo, int transferAmt) {
		long bal, mainbalance2, update1 = 0, update2 = 0;
		BankBean bankBean = (BankBean) hm.get(SourceAccNo);

		bal = bankBean.getBalance();
		System.out.println("soruce"+bal);
		update1 = bal - transferAmt;
		System.out.println("soruce"+update1);
		bankBean.setBalance(update1);

		BankBean bankBean2 = (BankBean) hm.get(destAccNo);
		mainbalance2 = bankBean2.getBalance();
		update2 = mainbalance2 + transferAmt;
		bankBean2.setBalance(update2);
		long finalResult=bankBean.getBalance();
		long uniqueID = rand.nextInt(100000); 
		long uniqueID2 = rand.nextInt(100000); 
		
		String trans1=bankBean.getTran()+"Transaction ID : "+uniqueID+" Account Debited by : "+transferAmt+" \n";
		String trans2=bankBean2.getTran()+"Transaction ID : "+uniqueID2+" Account Credited by : "+transferAmt+" \n";
		
		bankBean.setTran(trans1);
		bankBean2.setTran(trans2);
		return finalResult;
	}
	public String getTransaction(long accNo) {
		BankBean bankBean=(BankBean)hm.get(accNo);
		String st = bankBean.getTran();
		
		return st;
		}
}
