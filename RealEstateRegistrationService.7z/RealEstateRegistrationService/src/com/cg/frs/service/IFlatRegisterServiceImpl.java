package com.cg.frs.service;

import com.cg.frs.dto.FlatRegisterDTO;

public interface IFlatRegisterServiceImpl {
	public long registerflat(FlatRegisterDTO frd1);
	/*public FlatRegisterDTO displayFlatdetails(long uniqueId);*/
}
