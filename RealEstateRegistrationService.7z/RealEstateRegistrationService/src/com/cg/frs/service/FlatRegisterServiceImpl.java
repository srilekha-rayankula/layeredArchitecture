package com.cg.frs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.frs.dao.FlatRegistrationDAO;
import com.cg.frs.dto.FlatRegisterDTO;
import com.cg.frs.exception.MyException;

public class FlatRegisterServiceImpl implements IFlatRegisterServiceImpl {
	FlatRegistrationDAO frd = new FlatRegistrationDAO(); // DAO class
	FlatRegisterDTO frd1; // FlatRegister Bean class
	Scanner sc = new Scanner(System.in);

	public ArrayList<Integer> getAllOwnerIds() {

		return frd.getAllOwnerIds();
	}

	public long registerflat(FlatRegisterDTO frd1) {
		return frd.registerflat(frd1);

	}

	/*
	 * public FlatRegisterDTO displayFlatdetails(long uniqueId) { return
	 * frd.displayFlatdetails(uniqueId);
	 * 
	 * }
	 */
	public List<FlatRegisterDTO> getAllDetails() throws MyException {
		return frd.getAllDetails();

	}

	public int IDcheck(int ownerId) { // OwnerId Check
		while (true) {
			try {
				if (ownerId == 1 || ownerId == 2 || ownerId == 3) {
					return ownerId;
				} else {
					throw new MyException("Owner does not exists Entrer valid ownerId");

				}
			} catch (MyException E) {
				System.out.println(E);
				ownerId = sc.nextInt();
			}
		}

	}

	public int numbercheck(int number) { // Amount check
		while (true) {
			if (number <= 0) {
				System.out.println("value should be greater than 0.");
				System.out.println("Enter again: ");
				number = sc.nextInt();
			} else {
				return number;
			}
		}

	}

}
