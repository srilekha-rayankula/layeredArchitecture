package com.cg.frs.dto;

public class FlatRegisterDTO {
       int ownerId;
       String flatType;
       int flatArea;
       int rentAmount;
       int depAmount;
       public FlatRegisterDTO(int ownerId, String flatType, int flatArea, int rentAmount, int depAmount) {
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depAmount = depAmount;
	}
	
	@Override
	public String toString() {
		return "FlatRegisterDTO [ownerId=" + ownerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depAmount=" + depAmount + "]";
	}

	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public int getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}
	public long getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(int rentAmount) {
		this.rentAmount = rentAmount;
	}
	public long getDepAmount() {
		return depAmount;
	}
	public void setDepAmount(int depAmount) {
		this.depAmount = depAmount;
	}
       
}
