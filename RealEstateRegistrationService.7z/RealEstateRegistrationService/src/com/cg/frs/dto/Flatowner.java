package com.cg.frs.dto;

public class Flatowner {
  int ownerIds;
  String ownerName;
  String mobNo;
  
public Flatowner(int ownerIds, String ownerName, String mobNo) {
	super();
	this.ownerIds = ownerIds;
	this.ownerName = ownerName;
	this.mobNo = mobNo;
}
public int getOwnerIds() {
	return ownerIds;
}
public void setOwnerIds(int ownerIds) {
	this.ownerIds = ownerIds;
}
@Override
public String toString() {
	return "Flatowner [ownerIds=" + ownerIds + ", ownerName=" + ownerName + ", mobNo=" + mobNo + "]";
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public String getMobNo() {
	return mobNo;
}
public void setMobNo(String mobNo) {
	this.mobNo = mobNo;
}
  
}
