package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import com.cg.frs.dto.FlatRegisterDTO;
import com.cg.frs.dto.Flatowner;
import com.cg.frs.exception.MyException;

public class FlatRegistrationDAO implements IFlatRegistrationDAO {
	Random rand = new Random(); // Random class

	Flatowner obj; // Flat owner Bean class
	private static ArrayList<Integer> l2 = new ArrayList<Integer>();
	static Map<Integer, Flatowner> owners = new HashMap<Integer, Flatowner>();
	static {
		owners.put(1, new Flatowner(1, "vaishali", "9023002122"));
		owners.put(2, new Flatowner(2, "Megha", "9643221234"));
		owners.put(3, new Flatowner(3, "Manish", "5453221234"));
	}

	public ArrayList<Integer> getAllOwnerIds() {
		for (Map.Entry<Integer, Flatowner> entry : owners.entrySet()) {
			l2.add(entry.getValue().getOwnerIds());

		}
		return l2;
	}

	HashMap<Long, FlatRegisterDTO> hm = new HashMap<Long, FlatRegisterDTO>();
	private static List<FlatRegisterDTO> l1 = new ArrayList<FlatRegisterDTO>();

	public long registerflat(FlatRegisterDTO frd1) { // FlatRegister
		long uniqueId = (long) ((Math.random() * ((9999 - 1000) + 1)) + 1000);
		hm.put(uniqueId, frd1);

		return uniqueId;
	}

	/*
	 * public FlatRegisterDTO displayFlatdetails(long uniqueId) { // Display Flat
	 * Details FlatRegisterDTO frd1 = (FlatRegisterDTO) hm.get(uniqueId); return
	 * frd1;
	 * 
	 * }
	 */
	public List<FlatRegisterDTO> getAllDetails() throws MyException {
		for (Entry<Long, FlatRegisterDTO> entry : hm.entrySet()) {
			l1.add(entry.getValue());
			// System.out.println(l1);
		}
        if(l1.isEmpty()) 
        	System.out.println("No register Datails");
        else
        	System.out.println("Your register details");
        
		return l1;

	}

}
