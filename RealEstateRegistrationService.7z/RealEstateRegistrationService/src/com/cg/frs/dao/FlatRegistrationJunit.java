package com.cg.frs.dao;

import org.junit.Test;

import junit.framework.Assert;

public class FlatRegistrationJunit {
	@Test
	public void testDetails() {
		String str = "chennai";
		String actual = "chennai";
		Assert.assertEquals(str, actual);
	}
}
