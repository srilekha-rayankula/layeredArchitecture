package com.cg.frs.dao;

import com.cg.frs.dto.FlatRegisterDTO;

public interface IFlatRegistrationDAO {
	public long registerflat(FlatRegisterDTO frd1);
	/*public FlatRegisterDTO displayFlatdetails(long uniqueId);*/
}
