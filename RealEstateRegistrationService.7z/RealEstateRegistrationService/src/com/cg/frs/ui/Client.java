package com.cg.frs.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegisterDTO;
import com.cg.frs.dto.Flatowner;
import com.cg.frs.exception.MyException;
import com.cg.frs.service.FlatRegisterServiceImpl;

public class Client {
	public static void main(String[] args) {
		int ch;
		@SuppressWarnings("unused")
		Flatowner fo;
		FlatRegisterServiceImpl frs = new FlatRegisterServiceImpl(); // Service class
		do {
			System.out.println("1.Register Flat\n 2.Display Flat Registration Details\n 3.Exit"); // Cases to follow
			System.out.println("Enter Your Choice");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			try {
			ch = sc.nextInt();
			switch (ch) {
			
			case 1: // Registering Flat
				System.out.println("Exisiting Owner Ids " + frs.getAllOwnerIds());
				System.out.println("Please Enter your owner Id from above list :");
				int ownerId = frs.IDcheck(sc.nextInt());
				System.out.println("Select flat Type(1BHK,2BHK) :");
				String flatType = sc.next();
				System.out.println("Enter Flat Area in sq.ft:");
				int flatArea = frs.numbercheck(sc.nextInt());
				System.out.println("Enter Desired rent Amount Rs:");
				int rentAmount = frs.numbercheck(sc.nextInt());
				System.out.println("Enter Your deposit Amount Rs:");
				int depAmount = frs.numbercheck(sc.nextInt());
				if (depAmount < rentAmount) {
					System.out.println("Enter valid deposit Amount it should be greater than rentAmount");
					depAmount = sc.nextInt();
				}
				FlatRegisterDTO frd = new FlatRegisterDTO(ownerId, flatType, flatArea, rentAmount, depAmount);
				long uniqueId = frs.registerflat(frd);
				 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				   LocalDateTime now = LocalDateTime.now();  
				System.out.println("Flat Successfully registered.Register id :" + "<" + uniqueId + ">"+dtf.format(now));
				break;
			case 2:
				/*
				 * System.out.println("Enter Your UniqueId : "); //Displaying Flat Details
				 * uniqueId = sc.nextLong(); FlatRegisterDTO frdobj =
				 * frs.displayFlatdetails(uniqueId);
				 * System.out.println("*************Your Details****************");
				 * System.out.println("Your owner Id is :" + frdobj.getOwnerId());
				 * System.out.println("Your Flat Type is:" + frdobj.getFlatType());
				 * System.out.println("Flat Area :" + frdobj.getFlatArea());
				 * System.out.println("Rent Amount :" + frdobj.getRentAmount());
				 * System.out.println("Deposit Amount :" + frdobj.getDepAmount());
				 */
				//System.out.println("Printing all the details");
				try {
					System.out.println(frs.getAllDetails());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					//System.out.println("NO register details");
					e1.printStackTrace();
				}

				break;

			case 3:
				System.exit(0); // exit
			default:
				throw new MyException("Enter valid case");
			}}
			catch (MyException E) {
				System.out.println(E);
				ch = sc.nextInt();
			}
		} while (ch != 4);
	}

}
