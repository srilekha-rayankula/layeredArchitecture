package com.capgemini.contactbook.ui;

import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.ContactBookService;

public class client {
	public static void main(String[] args) {
		ContactBookService cbs = new ContactBookService();     //Service class
		int ch;
		do {
			System.out.println("1.Enter Enquiry Details \n2. View Enquiry Details on Id \n3. Exit");
			System.out.println("Entetr Your Choice");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter Your First Name :");
				String firstName = cbs.namecheck(sc.next());     //First Name
				System.out.println("Enter your Last Name :");
				String lastName = cbs.namecheck(sc.next());       // Last Name
				System.out.println("Enter Your Contact Number :");
				long contactNumber = cbs.mobcheck(sc.nextLong());     // Contact Number
				System.out.println("Enter your preferred Domain :");   
				String preferredDomain = cbs.namecheck(sc.next());       //Domain
				System.out.println("Enter Your Preferred Location :");
				String preferredLocation = cbs.namecheck(sc.next());       //Location
				EnquiryBean eb = new EnquiryBean(firstName, lastName, contactNumber, preferredDomain, preferredLocation);
				long uniqueId = cbs.enquiryDetails(eb);
				System.out.println("Thank you, your Unique Id is " + uniqueId + " we will contact you shortly");
				break;
			case 2:
				
				System.out.println("Enter your unique Id");
				uniqueId = sc.nextLong();
				EnquiryBean eb1 = cbs.viewDetails(uniqueId);
				System.out.println("************Your Details**********************");
				System.out.println("Your First Name :" + eb1.getFirstName());
				System.out.println("your Last Name :" + eb1.getLastName());
				System.out.println(" Contact Number :" + eb1.getContactNumber());
				System.out.println("your preferred Domain :" + eb1.getPreferredDomain());
				System.out.println("Your Preferred Location :" + eb1.getPreferredLocation());
				break;
			case 3:
				System.exit(0);
			}

		} while (ch != 4);
        
	}
	
}
