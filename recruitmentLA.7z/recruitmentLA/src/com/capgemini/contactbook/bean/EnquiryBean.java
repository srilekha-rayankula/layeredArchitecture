package com.capgemini.contactbook.bean;

public class EnquiryBean {
     String firstName;
	 String lastName;
	 long contactNumber;
	 String preferredDomain;
	 String	preferredLocation;
	 
	public EnquiryBean(String firstName, String lastName, long contactNumber, String preferredDomain,
			String preferredLocation) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber;
		this.preferredDomain = preferredDomain;
		this.preferredLocation = preferredLocation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPreferredDomain() {
		return preferredDomain;
	}
	public void setPreferredDomain(String preferredDomain) {
		this.preferredDomain = preferredDomain;
	}
	public String getPreferredLocation() {
		return preferredLocation;
	}
	public void setPreferredLocation(String preferredLocation) {
		this.preferredLocation = preferredLocation;
	}

}
