package com.capgemini.contactbook.service;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;

public class ContactBookService implements ContactBookServiceI {
	ContactBookDao cbd = new ContactBookDao();         //DAO class
    Scanner sc = new Scanner(System.in);
  public long enquiryDetails(EnquiryBean bean) {
	 return  cbd.enquiryDetails(bean);
  }
public EnquiryBean viewDetails(long uniqueId) {
	return cbd.viewDetails(uniqueId);
	
}
public String namecheck(String name) {                   //name validation
	while(true) {
		if(Pattern.matches("([A-Z])*([a-z])*", name)){
			return name;
		}
		else {
			System.out.println("Name should only have alphabets.");
			System.out.println("Enter again: ");
			name = sc.next();
		}
	}
}
public long mobcheck(long phn) {                     //mobile validation
	while(true) {
	if(String.valueOf(phn).length()<10) {
		System.out.println("Enter valid phone number");
		phn=sc.nextLong();
	}
	else {
	return phn;
	}
	}
}
}
