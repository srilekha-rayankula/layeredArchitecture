package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookServiceI {
	 public long enquiryDetails(EnquiryBean bean);
	 public EnquiryBean viewDetails(long uniqueId);
}
