package com.capgemini.contactbook.dao;

import org.junit.Test;

import junit.framework.Assert;

public class ContactBookjunit {
	@Test
	public void testDetails() {
		String str = "chennai";
		String actual = "chennai";
		Assert.assertEquals(str, actual);
	}
 }
