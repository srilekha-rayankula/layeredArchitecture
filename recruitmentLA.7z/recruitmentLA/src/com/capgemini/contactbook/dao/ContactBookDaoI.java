package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookDaoI {
	public long enquiryDetails(EnquiryBean bean);
	public EnquiryBean viewDetails(long uniqueId);
}
