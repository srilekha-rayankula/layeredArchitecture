package com.capgemini.contactbook.dao;

import java.util.HashMap;
import java.util.Random;

import com.capgemini.contactbook.bean.EnquiryBean;

public class ContactBookDao implements ContactBookDaoI{
	HashMap<Long, EnquiryBean> hm = new HashMap<Long, EnquiryBean>();
	Random rand = new Random();                //Generate unique Id         

	public long enquiryDetails(EnquiryBean bean) {
		long uniqueId = rand.nextInt(10000);
		hm.put(uniqueId, bean);
		/*bean = (EnquiryBean) hm.get(uniqueId);*/
		return uniqueId;
	}

	public EnquiryBean viewDetails(long uniqueId) {
        EnquiryBean bean = (EnquiryBean) hm.get(uniqueId);
        
        //System.out.println(bean.getPreferredLocation());
		return bean;
	}

}
